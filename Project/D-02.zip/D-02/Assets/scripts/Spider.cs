﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spider : MonoBehaviour
{
	//=========================================
	// 蜘蛛的屬性
	//========================================= 
	private float speed;  //蜘蛛的速度


	//=========================================
	// 程式一開始的工作
	//=========================================
	void Start()
	{
		//---------------------
		// 設定蜘蛛的速度
		//---------------------
		Animator animator = GetComponent<Animator>();
		speed = Random.Range(0.1f, 0.4f);
		animator.speed = speed;
	}


	//=========================================
	// 程式一直重覆的工作
	//=========================================
	void Update()
	{
		//畫蜘蛛
		transform.position = Vector3.MoveTowards(transform.position, transform.position + Vector3.left, Time.deltaTime * speed);
	}
	//=========================================    
}