﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spider : MonoBehaviour
{
	//=========================================
	// 蜘蛛的屬性
	//=========================================
	private float speed;    //蜘蛛的速度
	private int direction;  //蜘蛛的方向


	//=========================================
	// 程式一開始的工作
	//=========================================
	void Start()
	{
		//---------------------
		// 設定蜘蛛的速度
		//---------------------
		Animator animator = GetComponent<Animator>();
		speed = Random.Range(0.5f, 1.4f);
		animator.speed = speed;

		//---------------------
		// 設定蜘蛛的方向
		//---------------------
		direction = Random.Range(0, 8);
		ChangeDirection();
	}
	//=========================================



	//=========================================
	// 程式一直重覆的工作
	//=========================================
	void Update()
	{
		Vector3 dest=transform.position;   //蜘蛛的下個目的地

		//有時候蜘蛛會改方向
		if(Random.Range(0.0f, 100.0f) < 1)
		{
			ChangeDirection();
		}

		//畫蜘蛛移動
		if (direction == 0)
		{
			dest = transform.position + Vector3.left;
		}
		else if (direction == 1)
		{
			dest = transform.position + (Vector3.left + Vector3.up)/1.414f;
		}
		else if (direction == 2)
		{
			dest = transform.position + Vector3.up;
		}
		else if (direction == 3)
		{
			dest = transform.position + (Vector3.right + Vector3.up) / 1.414f;
		}
		else if (direction == 4)
		{
			dest = transform.position + Vector3.right;
		}
		else if (direction == 5)
		{
			dest = transform.position + (Vector3.right + Vector3.down) / 1.414f;
		}
		else if (direction == 6)
		{
			dest = transform.position + Vector3.down;
		}
		else if (direction == 7)
		{
			dest = transform.position + (Vector3.left + Vector3.down) / 1.414f;
		}

		transform.position = Vector3.MoveTowards(transform.position, dest, Time.deltaTime * speed);


		//如果走出範圍, 回收螢幕上的蜘蛛
		if(transform.position.x>10 || transform.position.x<-10 || transform.position.y > 5 || transform.position.y < -5)
		{
			Destroy(gameObject);
		}

	}
	//=========================================



	//=========================================
	// 改變蜘蛛方向
	//=========================================
	void ChangeDirection()
	{
		//----------------------
		// 隨意正時針或逆時針轉
		//----------------------
		if(Random.Range(-1f, 1f) > 0)
		{
			direction += 1;
		}
		else
		{
			direction -= 1;
		}

		direction += 8;
		direction %= 8;


		//----------------------
		// 清除原有動畫
		//----------------------
		Animator animator = GetComponent<Animator>();
		animator.SetBool("left", false);
		animator.SetBool("leftup", false);
		animator.SetBool("leftdown", false);
		animator.SetBool("right", false);
		animator.SetBool("rightup", false);
		animator.SetBool("rightdown", false);
		animator.SetBool("up", false);
		animator.SetBool("down", false);

		//----------------------
		// 設定現在動畫
		//----------------------
		if (direction == 0)
		{
			animator.SetBool("left", true);
		}
		else if (direction == 1)
		{
			animator.SetBool("leftup", true);
		}
		else if (direction == 2)
		{
			animator.SetBool("up", true);
		}
		else if (direction == 3)
		{
			animator.SetBool("rightup", true);
		}
		else if (direction == 4)
		{
			animator.SetBool("right", true);
		}
		else if (direction == 5)
		{
			animator.SetBool("rightdown", true);
		}
		else if (direction == 6)
		{
			animator.SetBool("down", true);
		}
		else if (direction == 7)
		{
			animator.SetBool("leftdown", true);
		}
	}
	//=========================================
}