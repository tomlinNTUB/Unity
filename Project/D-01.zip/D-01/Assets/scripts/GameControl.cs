﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameControl : MonoBehaviour {
    [Header("加入Explosion預設物件")]
    public Explosion explosion;

    //=========================================
    // 程式一開始的工作
    //=========================================
    void Start () {}



    //=========================================
    // 程式一直重覆的工作
    //=========================================
    void Update () {
        //--------------
        // 結束程式
        //--------------
        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }

        //-------------------
        // 如果按了空白鍵
        //-------------------
        if (Input.GetKey(KeyCode.Space))
        {
            //將滑鼠位址轉成遊戲地圖座標
            var mp = Input.mousePosition;
            mp.z = 10;
            mp = Camera.main.ScreenToWorldPoint(mp);

            // 指定滑鼠附近的亂數位置->爆炸位置
            explosion.transform.position = mp;
            explosion.transform.position += new Vector3(Random.Range(-0.2f, 0.2f), Random.Range(-0.2f, 0.2f), 0);

            // 在地圖上產生爆炸物件
            Instantiate(explosion);
        }
    }
    //=========================================
}
